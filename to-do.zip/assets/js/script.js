document.addEventListener('DOMContentLoaded', function() {
    
    document.addEventListener('click', function(e) {
        // Delete buttons
        if (e.target.closest('.btn-danger') && !e.target.closest('.btn-danger').hasAttribute('data-confirmed')) {
            const message = e.target.closest('[data-confirm]') 
                ? e.target.closest('[data-confirm]').getAttribute('data-confirm')
                : 'Are you sure you want to perform this action?';
            
            if (!confirm(message)) {
                e.preventDefault();
            }
        }
        
        // Logout link
        if (e.target.closest('a[href*="logout"]')) {
            if (!confirm('Are you sure you want to logout?')) {
                e.preventDefault();
            }
        }
    });
});
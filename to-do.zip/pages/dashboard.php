<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (!isLoggedIn()) {
    redirect(BASE_URL . '/login.php');
}

// Get user tasks
global $pdo;
$userId = getUserId();

// Add new task
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_task'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $dueDate = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
    
    if (!empty($title)) {
        $stmt = $pdo->prepare("INSERT INTO tasks (user_id, title, description, due_date) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $title, $description, $dueDate]);
        setFlash('success', 'Task added successfully');
        redirect(BASE_URL . '/dashboard.php');
    } else {
        setFlash('error', 'Task title is required');
    }
}

// Update task status
if (isset($_GET['toggle_status'])) {
    try {
        $taskId = (int)$_GET['toggle_status'];
        $userId = getUserId();
        
        // Verify task belongs to user
        $stmt = $pdo->prepare("SELECT id FROM tasks WHERE id = ? AND user_id = ?");
        $stmt->execute([$taskId, $userId]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception("Task not found or doesn't belong to user");
        }
        
        $stmt = $pdo->prepare("UPDATE tasks SET status = IF(status='pending', 'completed', 'pending') WHERE id = ? AND user_id = ?");
        $stmt->execute([$taskId, $userId]);
        
        setFlash('success', 'Task status updated');
    } catch (Exception $e) {
        error_log("Error updating task status: " . $e->getMessage());
        setFlash('error', 'Failed to update task status');
    }
    redirect(BASE_URL . '/dashboard.php');
}

// Get active tasks
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ? AND is_deleted = FALSE ORDER BY due_date ASC, created_at DESC");
$stmt->execute([$userId]);
$tasks = $stmt->fetchAll();

$flash = getFlash();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?= APP_NAME ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;600&family=Space+Grotesk:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://kit.fontawesome.com/2899ec1a38.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
    <style>
/* DEBUG STYLES - REMOVE AFTER FIXING */
.overdue-badge {
  background-color: #ff6b6b !important;
  color: white !important;
  padding: 0.3rem 0.6rem !important;
  border-radius: 4px !important;
  font-size: 0.7rem !important;
  font-weight: bold !important;
  display: inline-block !important;
  margin-left: 0.5rem !important;
  text-transform: uppercase !important;
  animation: pulse 1.5s infinite !important;
}

@keyframes pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
}
</style>
</head>
<body>
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <div id="particles-js"></div>
    <div class="container">
        <header>
            <h1><i class="fas fa-tachometer-alt"></i> Welcome, <?= $_SESSION['username'] ?></h1>
            <nav>
                <a href="dashboard.php" class="active"><i class="fas fa-tasks"></i> Tasks</a>
                <a href="recycle-bin.php"><i class="fas fa-trash-alt"></i> Recycle Bin</a>
                <a href="<?= BASE_URL ?>/?logout" class="btn btn-danger" 
   onclick="return confirm('Are you sure you want to logout?')">
   <i class="fas fa-sign-out-alt"></i> Logout
</a>
            </nav>
        </header>
        
        <?php if ($flash): ?>
            <div class="alert alert-<?= $flash['type'] ?>">
                <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                <?= $flash['message'] ?>
            </div>
        <?php endif; ?>
        
        <section class="add-task card">
            <h2><i class="fas fa-plus-circle"></i> Add New Task</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="title">Task Title</label>
                    <input type="text" name="title" id="title" placeholder="Enter task title" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description (optional)</label>
                    <textarea name="description" id="description" placeholder="Enter task description"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="due_date">Due Date (optional)</label>
                    <input type="datetime-local" id="due_date" name="due_date">
                </div>
                
                <button type="submit" name="add_task" class="btn"><i class="fas fa-plus"></i> Add Task</button>
            </form>
        </section>
        
        <section class="task-list">
            <h2><i class="fas fa-list"></i> Your Tasks</h2>
            
            <?php if (empty($tasks)): ?>
                <p>No tasks found. Add your first task above!</p>
            <?php else: ?>
                <div class="task-filters">
                    <a href="?sort=due" class="btn btn-sm"><i class="fas fa-calendar-alt"></i> Sort by Due Date</a>
                    <a href="?sort=created" class="btn btn-sm"><i class="fas fa-clock"></i> Sort by Creation</a>
                </div>
                
                <div class="tasks">
<?php foreach ($tasks as $task): 
    $isOverdue = $task['due_date'] && 
                 strtotime($task['due_date']) < time() && 
                 $task['status'] === 'pending';
    // Debug output - remove after testing
    echo "<!-- Task ID: {$task['id']}, Due: {$task['due_date']}, Overdue: " . ($isOverdue ? 'YES' : 'NO') . " -->\n";
?>
    <div class="task card <?= $task['status'] === 'completed' ? 'completed' : '' ?> <?= $isOverdue ? 'overdue' : '' ?>">
        <div class="task-header">
            <h3><?= htmlspecialchars($task['title']) ?></h3>
            <div class="task-actions">
                <a href="?toggle_status=<?= $task['id'] ?>" class="btn btn-sm">
                    <i class="fas fa-<?= $task['status'] === 'pending' ? 'check' : 'undo' ?>"></i>
                    <?= $task['status'] === 'pending' ? 'Mark Done' : 'Mark Pending' ?>
                </a>
                <a href="edit-task.php?id=<?= $task['id'] ?>" class="btn btn-sm btn-edit">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="delete-task.php?id=<?= $task['id'] ?>" class="btn btn-sm btn-danger" 
                    onclick="return confirm('Are you sure you want to move this task to Recycle Bin?')">
                    <i class="fas fa-trash"></i> Delete
                </a>
            </div>
        </div>
        
        <?php if (!empty($task['description'])): ?>
            <p class="task-description"><?= htmlspecialchars($task['description']) ?></p>
        <?php endif; ?>
        
        <div class="task-footer">
            <span class="task-status <?= $task['status'] ?>">
                <i class="fas fa-circle"></i> <?= ucfirst($task['status']) ?>
            </span>
            
<?php if ($task['due_date']): ?>
    <span class="task-due <?= $isOverdue ? 'overdue debug-overdue' : '' ?>">
        <i class="fas fa-calendar"></i> 
        Due: <?= date('M j, Y g:i A', strtotime($task['due_date'])) ?>
        <?php if ($isOverdue): ?>
            <span class="overdue-badge debug-badge">OVERDUE</span>
        <?php endif; ?>
    </span>
<?php endif; ?>
            
            <span class="task-created">
                <i class="fas fa-clock"></i> Created: <?= date('M j, Y', strtotime($task['created_at'])) ?>
            </span>
        </div>
    </div>
<?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        
 <?php include '../includes/footer.php'; ?>
    </div>
    
    <script src="../assets/js/script.js"></script>
    <script>
// Debug CSS Loading
console.log("Checking CSS files...");
Array.from(document.styleSheets).forEach(sheet => {
    console.log(sheet.href || "Inline Style");
});

// Debug Overdue Elements
document.addEventListener('DOMContentLoaded', function() {
    const badges = document.querySelectorAll('.overdue-badge');
    console.log(`Found ${badges.length} overdue badges`);
    
    badges.forEach(badge => {
        console.log('Badge:', badge);
        const styles = window.getComputedStyle(badge);
        console.log('Background:', styles.backgroundColor);
        console.log('Display:', styles.display);
        
        // Temporary force styles if needed
        badge.style.cssText = `
            background-color: #ff6b6b !important;
            color: white !important;
            padding: 0.3rem 0.6rem !important;
            display: inline-block !important;
        `;
    });
});
        // Preloader
        window.addEventListener('load', () => {
            const preloader = document.getElementById('preloader');
            setTimeout(() => {
                preloader.classList.add('hidden');
            }, 1000);
        });

        // Particles.js configuration
        particlesJS('particles-js', {
            particles: {
                number: { value: 80, density: { enable: true, value_area: 800 } },
                color: { value: ['#20c997', '#ff6b6b', '#6c5ce7'] },
                shape: { type: 'circle' },
                opacity: { value: 0.5, random: true },
                size: { value: 3, random: true },
                line_linked: { enable: false },
                move: {
                    enable: true,
                    speed: 2,
                    direction: 'none',
                    random: true,
                    straight: false,
                    out_mode: 'out'
                }
            },
            interactivity: {
                detect_on: 'canvas',
                events: {
                    onhover: { enable: true, mode: 'repulse' },
                    onclick: { enable: true, mode: 'push' }
                }
            },
            retina_detect: true
        });
    </script>
</body>
</html>
<?php
// App configuration
define('APP_NAME', 'To-Do App');
define('BASE_URL', 'http://localhost/to-do/');
define('ERROR_LOG_FILE', __DIR__ . '/../error.log');

// Error reporting
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', ERROR_LOG_FILE);
error_reporting(E_ALL);

// Session configuration
session_start([
    'name' => 'TodoAppSession',
    'cookie_lifetime' => 86400,
    'cookie_secure' => isset($_SERVER['HTTPS']),
    'cookie_httponly' => true,
    'cookie_samesite' => 'Strict',
    'use_strict_mode' => true
]);

if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} elseif (time() - $_SESSION['created'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

// Custom error handler
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    $message = sprintf(
        "[%s] Error %s: %s in %s on line %d",
        date('Y-m-d H:i:s'),
        $errno,
        $errstr,
        $errfile,
        $errline
    );
    error_log($message);
    return true;
});

// Exception handler
set_exception_handler(function($exception) {
    $message = sprintf(
        "[%s] Exception: %s in %s on line %d\nStack trace:\n%s",
        date('Y-m-d H:i:s'),
        $exception->getMessage(),
        $exception->getFile(),
        $exception->getLine(),
        $exception->getTraceAsString()
    );
    error_log($message);
    http_response_code(500);
    die('An error occurred. Please try again later.');
});

if (!empty($_SESSION['site_blocked'])) {
    die('🚫 Website Blocked: The Owner\'s Remarks Were Changed.');
}

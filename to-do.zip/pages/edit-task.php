<?php
require_once '../includes/auth.php';

if (!isLoggedIn()) {
    redirect(BASE_URL . '/login.php');
}

global $pdo;
$userId = getUserId();

// Get task to edit
$taskId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$task = null;

try {
    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?");
    $stmt->execute([$taskId, $userId]);
    $task = $stmt->fetch();
    
    if (!$task) {
        throw new Exception("Task not found");
    }
} catch (Exception $e) {
    error_log("Error fetching task: " . $e->getMessage());
    setFlash('error', 'Task not found');
    redirect(BASE_URL . '/dashboard.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $title = trim($_POST['title']);
        $description = trim($_POST['description']);
        $dueDate = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
        
        if (empty($title)) {
            throw new Exception("Task title is required");
        }
        
        $stmt = $pdo->prepare("UPDATE tasks SET title = ?, description = ?, due_date = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$title, $description, $dueDate, $taskId, $userId]);
        
        setFlash('success', 'Task updated successfully');
        redirect(BASE_URL . '/dashboard.php');
    } catch (Exception $e) {
        error_log("Error updating task: " . $e->getMessage());
        setFlash('error', 'Failed to update task: ' . $e->getMessage());
    }
}

$flash = getFlash();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Task - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Edit Task</h1>
            <nav>
                <a href="dashboard.php">Back to Tasks</a>
                <a href="?logout" class="btn btn-danger">Logout</a>
            </nav>
        </header>
        
        <?php if ($flash): ?>
            <div class="alert alert-<?= $flash['type'] ?>">
                <?= $flash['message'] ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="title">Task Title</label>
                <input type="text" id="title" name="title" value="<?= htmlspecialchars($task['title']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description"><?= htmlspecialchars($task['description']) ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="due_date">Due Date</label>
                <input type="datetime-local" id="due_date" name="due_date" 
                    value="<?= $task['due_date'] ? htmlspecialchars(date('Y-m-d\TH:i', strtotime($task['due_date']))) : '' ?>">
            </div>
            
            <button type="submit" class="btn">Update Task</button>
        </form>
    </div>
</body>
</html>
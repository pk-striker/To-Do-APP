<!-- footer.php -->
<footer id="watermark-striker" data-checksum="made-by-striker-v1">
    Made by Striker
</footer>

<script>
window.addEventListener('load', async () => {
    const footer = document.getElementById('watermark-striker');
    const originalText = 'Made by Striker';
    const checksum = 'made-by-striker-v1';

    let tampered = false;

    if (!footer) {
        console.warn('🚨 Footer missing');
        tampered = true;
    } else {
        if (footer.textContent.trim() !== originalText) {
            console.warn('🚨 Footer text changed');
            tampered = true;
        }

        if (footer.getAttribute('data-checksum') !== checksum) {
            console.warn('🚨 Footer checksum changed');
            tampered = true;
        }
    }

    if (tampered) {
        try {
            const res = await fetch('block_site.php', { method: 'POST' });
            if (res.ok) {
                console.log('✅ block_site.php triggered');
                window.location.reload();
            } else {
                alert('❌ Server rejected block request');
            }
        } catch (e) {
            alert('❌ Error contacting server: ' + e.message);
        }
    }
});
</script>

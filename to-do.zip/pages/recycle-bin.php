<?php
require_once '../includes/auth.php';
include '../includes/config.php';

if (!isLoggedIn()) {
    redirect(BASE_URL . '/login.php');
}

global $pdo;
$userId = getUserId();

// Restore task
if (isset($_GET['restore'])) {
    $taskId = (int)$_GET['restore'];
    
    $stmt = $pdo->prepare("UPDATE tasks SET is_deleted = FALSE, deleted_at = NULL WHERE id = ? AND user_id = ?");
    $stmt->execute([$taskId, $userId]);
    setFlash('success', 'Task restored successfully');
    redirect(BASE_URL . '/recycle-bin.php');
}

// Permanently delete task
if (isset($_GET['delete_permanent'])) {
    $taskId = (int)$_GET['delete_permanent'];
    
    $stmt = $pdo->prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?");
    $stmt->execute([$taskId, $userId]);
    setFlash('success', 'Task permanently deleted');
    redirect(BASE_URL . '/recycle-bin.php');
}

// Get deleted tasks
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ? AND is_deleted = TRUE ORDER BY deleted_at DESC");
$stmt->execute([$userId]);
$deletedTasks = $stmt->fetchAll();

$flash = getFlash();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recycle Bin - <?= APP_NAME ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;600&family=Space+Grotesk:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://kit.fontawesome.com/2899ec1a38.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
</head>
<body>
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <div id="particles-js"></div>
    <div class="container">
                <header>
            <h1><i class="fas fa-tachometer-alt"></i> Welcome, <?= $_SESSION['username'] ?></h1>
            <nav>
                <a href="dashboard.php"><i class="fas fa-tasks"></i> Tasks</a>
                <a href="recycle-bin.php" class="active"><i class="fas fa-trash-alt"></i> Recycle Bin</a>
                <a href="<?= BASE_URL ?>/?logout" class="btn btn-danger" 
   onclick="return confirm('Are you sure you want to logout?')">
   <i class="fas fa-sign-out-alt"></i> Logout
</a>
            </nav>
        </header>


        
        <?php if ($flash): ?>
            <div class="alert alert-<?= $flash['type'] ?>">
                <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                <?= $flash['message'] ?>
            </div>
        <?php endif; ?>
        
        <section class="recycle-bin">
            <?php if (empty($deletedTasks)): ?>
                <p>Recycle bin is empty</p>
            <?php else: ?>
                <div class="tasks">
                    <?php foreach ($deletedTasks as $task): ?>
                        <div class="task card deleted">
                            <div class="task-header">
                                <h3><?= htmlspecialchars($task['title']) ?></h3>
                                <div class="task-actions">
                                    <a href="?restore=<?= $task['id'] ?>" class="btn btn-sm btn-success">
                                        <i class="fas fa-undo"></i> Restore
                                    </a>
                                    <a href="?delete_permanent=<?= $task['id'] ?>" class="btn btn-sm btn-danger"
                                        onclick="return confirm('Are you sure you want to permanently delete this task?')">
                                        <i class="fas fa-trash"></i> Delete Permanently
                                    </a>
                                </div>
                            </div>
                            
                            <?php if (!empty($task['description'])): ?>
                                <p class="task-description"><?= htmlspecialchars($task['description']) ?></p>
                            <?php endif; ?>
                            
                            <div class="task-footer">
                                <span class="task-deleted">
                                    <i class="fas fa-clock"></i> Deleted: <?= date('M j, Y g:i A', strtotime($task['deleted_at'])) ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        
         <?php include '../includes/footer.php'; ?>
    </div>
    
    <script>
        // Preloader
        window.addEventListener('load', () => {
            const preloader = document.getElementById('preloader');
            setTimeout(() => {
                preloader.classList.add('hidden');
            }, 1000);
        });

        // Particles.js configuration
        particlesJS('particles-js', {
            particles: {
                number: { value: 80, density: { enable: true, value_area: 800 } },
                color: { value: ['#20c997', '#ff6b6b', '#6c5ce7'] },
                shape: { type: 'circle' },
                opacity: { value: 0.5, random: true },
                size: { value: 3, random: true },
                line_linked: { enable: false },
                move: {
                    enable: true,
                    speed: 2,
                    direction: 'none',
                    random: true,
                    straight: false,
                    out_mode: 'out'
                }
            },
            interactivity: {
                detect_on: 'canvas',
                events: {
                    onhover: { enable: true, mode: 'repulse' },
                    onclick: { enable: true, mode: 'push' }
                }
            },
            retina_detect: true
        });
    </script>
</body>
</html>
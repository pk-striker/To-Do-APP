<?php
require_once 'includes/auth.php';

// Handle logout
if (isset($_GET['logout'])) {
    try {
        logoutUser();
        setFlash('success', 'You have been logged out successfully');
    } catch (Exception $e) {
        error_log("Error during logout: " . $e->getMessage());
        setFlash('error', 'Error during logout');
    }
    redirect(BASE_URL . 'pages/login.php');
}

// Redirect to dashboard if logged in, otherwise to login
if (isLoggedIn()) {
    redirect(BASE_URL . 'pages/dashboard.php');
} else {
    redirect(BASE_URL . 'pages/login.php');
}
<?php
require_once '../includes/auth.php';

if (!isLoggedIn()) {
    redirect(BASE_URL . '/login.php');
}

global $pdo;
$userId = getUserId();

if (isset($_GET['id'])) {
    try {
        $taskId = (int)$_GET['id'];
        
        // Verify task belongs to user
        $stmt = $pdo->prepare("SELECT id FROM tasks WHERE id = ? AND user_id = ?");
        $stmt->execute([$taskId, $userId]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception("Task not found or doesn't belong to user");
        }
        
        // Soft delete (move to recycle bin)
        $stmt = $pdo->prepare("UPDATE tasks SET is_deleted = TRUE, deleted_at = NOW() WHERE id = ? AND user_id = ?");
        $stmt->execute([$taskId, $userId]);
        
        setFlash('success', 'Task moved to Recycle Bin');
    } catch (Exception $e) {
        error_log("Error deleting task: " . $e->getMessage());
        setFlash('error', 'Failed to delete task');
    }
}

redirect(BASE_URL . '/dashboard.php');
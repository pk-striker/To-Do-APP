<?php
require_once 'functions.php';

// Register a new user
function registerUser($username, $email, $password) {
    global $pdo;
    
    // Validate inputs
    if (empty($username) || empty($email) || empty($password)) {
        setFlash('error', 'All fields are required');
        return false;
    }
    
    // Check if username or email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    
    if ($stmt->rowCount() > 0) {
        setFlash('error', 'Username or email already exists');
        return false;
    }
    
    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new user
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $success = $stmt->execute([$username, $email, $hashedPassword]);
    
    if ($success) {
        setFlash('success', 'Registration successful. Please login.');
        return true;
    }
    
    setFlash('error', 'Registration failed. Please try again.');
    return false;
}

// Login user
function loginUser($username, $password) {
    global $pdo;
    
    // Find user by username
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        // Regenerate session ID to prevent session fixation
        session_regenerate_id(true);
        
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        return true;
    }
    
    setFlash('error', 'Invalid username or password');
    return false;
}

// Logout user
function logoutUser() {
    // Unset all session variables
    $_SESSION = array();

    // Delete the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(), 
            '', 
            time() - 42000,
            $params["path"], 
            $params["domain"],
            $params["secure"], 
            $params["httponly"]
        );
    }

    // Destroy the session
    session_destroy();
}
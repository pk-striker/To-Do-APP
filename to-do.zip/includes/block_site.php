<?php
session_start();
$_SESSION['site_blocked'] = true;
print_r($_SESSION);
http_response_code(200);
exit;
